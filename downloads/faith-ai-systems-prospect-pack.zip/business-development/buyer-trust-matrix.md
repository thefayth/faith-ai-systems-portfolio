# Buyer Trust Matrix

Use this page when a buyer, partner, investor, or referral source wants to know what to review first and which paid path fits.

This is a public-safe diligence guide. It connects visible proof to buyer concerns without exposing private engine source, credentials, prompts, adapters, production logs, rollback snapshots, customer data, or protected receipts.

## Fast Matrix

| Buyer concern | Public proof to review | What it supports | Best paid path | First action |
| --- | --- | --- | --- | --- |
| The website looks weaker than the real work. | [Portfolio](https://thefayth.github.io/faith-ai-systems-portfolio/), [Sample Deliverables](https://thefayth.github.io/faith-ai-systems-portfolio/sample-deliverables.html), [Public Proof Snapshots](https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-snapshots.html) | Route-by-route review, visual trust cleanup, CTAs, receipts, and safer publishing boundaries. | [AI Website Visual Cleanup](https://thefayth.github.io/faith-ai-systems-portfolio/ai-website-visual-cleanup.html) | Send the public URL, weakest pages, what should stay unchanged, and desired business result. |
| The private tool needs a credible public surface. | [GitHub/Public Surface Packaging](https://thefayth.github.io/faith-ai-systems-portfolio/github-public-surface-packaging.html), [Public Proof Index](https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-index.html), public repos | Public/private boundary, README trust, product positioning, and commercial CTAs without exposing private internals. | [GitHub / Public Surface Packaging](https://thefayth.github.io/faith-ai-systems-portfolio/github-public-surface-packaging.html) | Send the repo or public page, the protected boundary, and who needs to trust it. |
| The brand or product story feels inconsistent. | [Quote-First Offers](https://thefayth.github.io/faith-ai-systems-portfolio/offers.html), [Sample Deliverables](https://thefayth.github.io/faith-ai-systems-portfolio/sample-deliverables.html), [Buyer FAQ](https://thefayth.github.io/faith-ai-systems-portfolio/buyer-faq.html) | Brand-fit review across visuals, promise, audience, accessibility, proof, and conversion path. | [AI Brand System Audit](https://thefayth.github.io/faith-ai-systems-portfolio/ai-brand-system-audit.html) | Send public examples, audiences, what feels wrong, and what should not be changed. |
| The AI workflow is too chat-only or hard to repeat. | [Fantasia](https://thefayth.github.io/faith-ai-systems-portfolio/fantasia.html), [Proof And Boundaries](https://thefayth.github.io/faith-ai-systems-portfolio/proof-and-boundaries.html), [Opportunity Router](https://thefayth.github.io/faith-ai-systems-portfolio/opportunity-router.html) | Local task packets, receipts, checkpoints, owner authority, and safer handoffs. | [Local AI Workflow Setup](https://thefayth.github.io/faith-ai-systems-portfolio/local-ai-workflow-setup.html) | Describe the workflow, where files live, what must stay private, and what result should be repeatable. |
| Authorship, files, or provenance need protection. | [TheFAYTH File Type](https://thefayth.github.io/faith-ai-systems-portfolio/thefayth-file-type.html), [Protected File / Provenance Consulting](https://thefayth.github.io/faith-ai-systems-portfolio/protected-file-provenance-consulting.html), [Proof And Boundaries](https://thefayth.github.io/faith-ai-systems-portfolio/proof-and-boundaries.html) | Tamper-evident language, original-byte respect, selective disclosure, receipt discipline, and honest proof boundaries. | [Protected File / Provenance Consulting](https://thefayth.github.io/faith-ai-systems-portfolio/protected-file-provenance-consulting.html) | Describe the artifact type, what must be preserved, what can be disclosed, and the future proof need. |
| A partner or investor wants leverage without private code. | [Investor And Partner Brief](https://thefayth.github.io/faith-ai-systems-portfolio/investor-partner-brief.html), [Licensing And Partnership Paths](https://thefayth.github.io/faith-ai-systems-portfolio/licensing-and-partnership-paths.html), [Prospect Packet](https://thefayth.github.io/faith-ai-systems-portfolio/prospect-packet.html) | Productized service paths, protected implementation boundaries, licensing conversations, and public proof. | Licensing, managed pilot, implementation partnership, advisor diligence, or custom build | Ask for a scoped partner review and name the lane you want to evaluate. |

## Quick Review Path

1. Start with the [Opportunity Router](https://thefayth.github.io/faith-ai-systems-portfolio/opportunity-router.html) if the right lane is unclear.
2. Open the [Public Proof Index](https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-index.html) if diligence is the main need.
3. Use the [Prospect Packet](https://thefayth.github.io/faith-ai-systems-portfolio/prospect-packet.html) when forwarding the whole public-safe package.
4. Use [Request Scope](https://thefayth.github.io/faith-ai-systems-portfolio/scope-request.html) when ready to discuss a paid next step.

## What Not To Send First

- Passwords, API keys, app passwords, tokens, signed URLs, private source, or customer records.
- Raw prompts, production logs, rollback snapshots, private receipts, signing keys, or protected engine internals.
- Fixed-price expectations before scope, risk, access, and turnaround are clear.

## Best First Message

Use [FaithCheltenham.com/contact](https://faithcheltenham.com/contact/) and send:

- the public surface to review
- the audience or buyer you need to impress
- what feels weak or risky now
- the outcome you want
- deadline or launch window
- whether you want audit, implementation, demo, licensing, or partnership
- budget range if known

Good work deserves public proof that does not leak the engine. That is the line this matrix protects.

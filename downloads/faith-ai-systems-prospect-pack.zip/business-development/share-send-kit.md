# Share / Send Kit

Use this page when someone asks, "What should I send them?" It keeps the first conversation public-safe, buyer-friendly, and easy to forward.

## Send One Link First

[Faith AI Systems Prospect Packet](https://thefayth.github.io/faith-ai-systems-portfolio/prospect-packet.html)

This is the cleanest first link for buyers, investors, partners, and referral sources. It gives them the portfolio, offers, proof links, product pages, and downloadable packet without exposing private engine work.

## Fast Paths By Audience

### For Buyers

Send:

- [Work With Faith](https://thefayth.github.io/faith-ai-systems-portfolio/work-with-faith.html)
- [Opportunity Router](https://thefayth.github.io/faith-ai-systems-portfolio/opportunity-router.html)
- [Buyer Trust Matrix](https://thefayth.github.io/faith-ai-systems-portfolio/buyer-trust-matrix.html)
- [Quote-First Offers](https://thefayth.github.io/faith-ai-systems-portfolio/offers.html)
- [Sample Deliverables](https://thefayth.github.io/faith-ai-systems-portfolio/sample-deliverables.html)
- [Request Scope](https://thefayth.github.io/faith-ai-systems-portfolio/scope-request.html)

Best note:

I build owner-controlled AI systems for public website trust, GitHub packaging, brand audits, local AI workflows, and provenance. The fastest first step is a scoped pilot based on public surfaces only.

### For Investors Or Partners

Send:

- [Investor And Partner Brief](https://thefayth.github.io/faith-ai-systems-portfolio/investor-partner-brief.html)
- [Public Proof Index](https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-index.html)
- [Buyer Trust Matrix](https://thefayth.github.io/faith-ai-systems-portfolio/buyer-trust-matrix.html)
- [Public Proof Snapshots](https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-snapshots.html)
- [Buyer FAQ](https://thefayth.github.io/faith-ai-systems-portfolio/buyer-faq.html)
- [Prospect Packet](https://thefayth.github.io/faith-ai-systems-portfolio/prospect-packet.html)

Best note:

Faith is building a local-first AI systems portfolio around visual trust, public-safe product packaging, protected file/provenance workflows, and guarded creative operations. Public surfaces show the commercial lane; private engine work stays protected.

### For Referrals

Send:

- [Referral And Introduction Kit](https://thefayth.github.io/faith-ai-systems-portfolio/referral-introduction-kit.html)
- [Work With Faith](https://thefayth.github.io/faith-ai-systems-portfolio/work-with-faith.html)
- [Contact](https://faithcheltenham.com/contact/)

Best note:

I thought of Faith because she helps serious builders make their public surfaces match the quality of the work underneath. A good first fit is a website trust sprint, public GitHub packaging sprint, brand audit, local AI workflow setup, or provenance consulting conversation.

## What Not To Send First

- Passwords, API keys, app passwords, tokens, private source, or customer records.
- Production credentials, signed URLs, rollback snapshots, private receipts, or protected engine internals.
- Fixed-price promises. Use quote-first language until scope, access, risk, and timeline are clear.

## First Contact

Use [FaithCheltenham.com/contact](https://faithcheltenham.com/contact/) for serious business inquiries. Send public links first; scope safe access only after a project is approved.

# Referral And Introduction Kit

Use this page when someone wants to introduce Faith Cheltenham to a founder, investor, agency, nonprofit, public figure, product team, or operator who needs better public trust, AI workflow control, website visuals, GitHub packaging, or provenance strategy.

Primary contact path:

- `https://faithcheltenham.com/contact/`

Do not include passwords, private files, customer records, production logs, app credentials, signing keys, private source, unpublished prompts, or protected receipts in an introduction.

## Fast Positioning

Faith Cheltenham builds owner-controlled AI systems and public trust surfaces for people and teams whose real work is stronger than their website, GitHub, docs, visuals, or workflow currently show.

Good introductions include:

- founders with serious tools that need public-safe packaging
- businesses with generic, broken, repeated, or weak website visuals
- teams that need AI workflows with receipts and owner control
- creators or technologists who need provenance and protected-file strategy
- agencies that need a sharper AI-assisted visual cleanup lane
- investors or partners evaluating local-first AI operations and public trust systems

## Short Intro

Copy and adapt:

I want to introduce you to Faith Cheltenham. Faith builds owner-controlled AI systems and public trust surfaces: website visual cleanup, GitHub/public product packaging, local AI workflow setup, brand system audits, and provenance consulting. Her work is useful when the real capability is strong but the public surface does not yet create enough trust. Start here: `https://thefayth.github.io/faith-ai-systems-portfolio/` and contact her here: `https://faithcheltenham.com/contact/`.

## Founder / Buyer Intro

Copy and adapt:

I thought of Faith because your public surface may need the same thing she is building around: sharper trust, better visual proof, stronger GitHub/product packaging, and safer AI operations. She is especially good at turning messy but valuable systems into public-safe assets that explain the work without giving away the private engine. Her offer catalog is here: `https://thefayth.github.io/faith-ai-systems-portfolio/offers.html`.

## Investor / Partner Intro

Copy and adapt:

Faith Cheltenham is building a portfolio around owner-controlled AI operations, visual trust systems, public/private boundary discipline, and provenance tooling. The public surfaces are intentionally packaged without exposing the private engine. Her investor and partner brief is here: `https://thefayth.github.io/faith-ai-systems-portfolio/investor-partner-brief.html`.

## What To Ask For

The cleanest first ask is one of these:

- scoped website visual cleanup
- GitHub or public product-surface packaging
- AI brand system audit
- local AI workflow setup
- protected file or provenance consulting
- customer pilot
- licensing or partnership conversation

## What Makes A Strong Lead

A strong lead has:

- a real public URL, product, website, repo, or workflow
- a clear trust or presentation problem
- authority to make a decision or sponsor a pilot
- a deadline, launch, fundraise, customer push, or public visibility need
- respect for public/private boundaries
- willingness to scope work before asking for implementation

## What To Avoid

Avoid introductions where the person wants:

- free high-level strategy without a paid path
- private source or prompts as a condition of interest
- credential sharing in a first message
- vague "pick your brain" labor
- public claims that are not true yet
- automated posting, scraping, or platform behavior that could create account risk

## Best Next Step

Send the introduction, include the public portfolio link, and point the buyer to the contact page.

If they are serious, ask them to include:

- who they are
- what public surface needs help
- what outcome they want
- deadline or launch window
- whether they want audit, implementation, demo, licensing, or partnership
- rough budget range if known


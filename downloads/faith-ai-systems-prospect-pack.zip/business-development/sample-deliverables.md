# Sample Deliverables

Use this page when a buyer, partner, or investor wants to understand what Faith actually delivers in a scoped pilot or public-surface project.

These are public-safe examples of deliverable types, not private client work. They do not include private engine source, credentials, customer records, production logs, prompts, adapters, rollback snapshots, signing keys, or protected files.

Primary contact path:

- `https://faithcheltenham.com/contact/`

## Website Trust Sprint Deliverables

A Website Trust Sprint may include:

- public route inventory
- visual quality audit
- keep/change/remove recommendations
- generic, repeated, broken, draft-like, or off-brand image list
- CTA and conversion review
- trust-signal recommendations
- first-batch replacement plan
- source and usage boundary notes
- publish-ready handoff
- guarded implementation checklist where supported

Example receipt shape:

- route checked
- issue found
- risk level
- recommended action
- proposed replacement or copy direction
- source/provenance note
- publish status
- rollback note if implementation is included

## GitHub Trust Sprint Deliverables

A GitHub Trust Sprint may include:

- public/private boundary review
- README upgrade
- Work With Faith or commercial CTA page
- commercial offers page
- license and use-boundary notes
- public-safe screenshots or diagrams
- secret/private-file risk notes
- launch receipt
- verification checklist

Example receipt shape:

- repo name
- public files reviewed
- links added
- sensitive materials excluded
- commit or publication proof
- verifier result
- remaining public/private boundary notes

## Brand System Audit Deliverables

A Brand System Audit may include:

- visual language notes
- voice and positioning notes
- rejected-pattern list
- audience trust map
- accessibility and clarity review
- screenshot notes
- next-batch creative brief
- public-surface priority list

Example receipt shape:

- surface reviewed
- brand-fit issue
- audience impact
- keep/change/remove decision
- next creative move
- risk or sensitivity note
- review status

## Local AI Workflow Sprint Deliverables

A Local AI Workflow Sprint may include:

- workflow map
- folder and receipt structure
- task packet template
- review checklist
- safe automation rules
- handoff notes
- owner training walkthrough

Example receipt shape:

- workflow step
- input files
- output artifacts
- review gate
- automation boundary
- receipt path
- next action

## Provenance And Protected File Sprint Deliverables

A Provenance And Protected File Sprint may include:

- provenance needs map
- original-file handling notes
- public/private disclosure boundary
- local receipt structure
- proof-language review
- selective disclosure checklist
- TheFAYTH File Type concept walkthrough where appropriate

Example receipt shape:

- file type
- owner or creator label
- proof need
- what can be disclosed
- what must remain private
- receipt or hash strategy
- review status

## Investor Or Partner Diligence Deliverables

A diligence-oriented scope may include:

- public proof index
- live link map
- public repo review
- product boundary notes
- commercial path summary
- protected IP boundary
- customer/pilot fit notes
- next partnership questions

Example receipt shape:

- surface checked
- live status
- public proof found
- private boundary preserved
- open blocker
- recommended next action

## What The Buyer Does Not Receive By Default

Not included by default:

- private source code
- production adapters
- raw prompts
- target registries
- credentials or app passwords
- signing keys
- private receipts
- customer data
- protected records
- server access
- DNS or auth changes
- rights to redistribute private assets

Those require separate scope, contract terms, and safety review.

## What Makes The Deliverables Valuable

The value is not only the artifact. It is the judgment around:

- what to show publicly
- what to keep private
- what strengthens trust
- what creates risk
- what should be published now
- what should wait for better proof
- how to preserve ownership and leverage while making the work legible

## Request A Sample Scope

To request a scope, send:

- the pilot type you are considering
- your public URL or repo
- the outcome you want
- deadline or launch window
- whether you need audit, implementation, demo, licensing, or partnership
- budget range if known

Use the contact page: `https://faithcheltenham.com/contact/`


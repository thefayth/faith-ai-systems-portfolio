# Opportunity Router

Use this page when someone is interested but not sure what to ask for. It turns a vague conversation into a safer first scope.

If the buyer wants proof before choosing a lane, send the [Buyer Trust Matrix](https://thefayth.github.io/faith-ai-systems-portfolio/buyer-trust-matrix.html) first.

## Pick The Closest Situation

### My Website Looks Weaker Than My Work

Best fit:

[AI Website Visual Cleanup](https://thefayth.github.io/faith-ai-systems-portfolio/ai-website-visual-cleanup.html)

Use this when the problem is generic visuals, repeated images, broken assets, weak CTAs, unclear project pages, or public trust gaps.

First ask:

Send the public website URL, the pages that feel weakest, what should stay unchanged, and the business outcome you want.

### My Private Tool Needs A Credible Public Surface

Best fit:

[GitHub / Public Surface Packaging](https://thefayth.github.io/faith-ai-systems-portfolio/github-public-surface-packaging.html)

Use this when the real product is private, unfinished, or protected, but you still need public trust, documentation, proof links, and commercial CTAs.

First ask:

Send the public repo or current public page, what must stay private, and who needs to trust the project.

### My Brand Or Product Looks Inconsistent

Best fit:

[AI Brand System Audit](https://thefayth.github.io/faith-ai-systems-portfolio/ai-brand-system-audit.html)

Use this when your visuals, message, tone, screenshots, pitch, and product promise are not yet telling the same story.

First ask:

Send public examples, what feels wrong, what you admire, and which audiences matter most.

### My AI Workflow Is Too Loose Or Chat-Only

Best fit:

[Local AI Workflow Setup](https://thefayth.github.io/faith-ai-systems-portfolio/local-ai-workflow-setup.html)

Use this when you want AI help with receipts, checkpoints, owner authority, local files, and repeatable handoffs instead of scattered chats.

First ask:

Describe the workflow, where files live, what must stay private, and what result should be repeatable.

### I Need To Protect Authorship, Files, Or Provenance

Best fit:

[Protected File / Provenance Consulting](https://thefayth.github.io/faith-ai-systems-portfolio/protected-file-provenance-consulting.html)

Use this when original files, proof records, disclosure boundaries, authorship, or private archives matter.

First ask:

Describe the artifact type, what must be preserved, what can be disclosed, and what proof needs to exist later.

## If You Are A Partner Or Investor

Start here:

- [Investor And Partner Brief](https://thefayth.github.io/faith-ai-systems-portfolio/investor-partner-brief.html)
- [Buyer Trust Matrix](https://thefayth.github.io/faith-ai-systems-portfolio/buyer-trust-matrix.html)
- [Public Proof Snapshots](https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-snapshots.html)
- [Prospect Packet](https://thefayth.github.io/faith-ai-systems-portfolio/prospect-packet.html)

Good conversation:

Ask about licensing, implementation partners, agency packaging, productized services, or a scoped pilot.

## If You Are Referring Someone

Start here:

- [Share / Send Kit](https://thefayth.github.io/faith-ai-systems-portfolio/share-send-kit.html)
- [Referral And Introduction Kit](https://thefayth.github.io/faith-ai-systems-portfolio/referral-introduction-kit.html)

Good introduction:

Faith helps serious builders make public surfaces match the quality of the work underneath. A useful first scope is bounded, public-safe, and does not require credentials in the first message.

## What To Send First

- Public URL, repo, screenshots, or non-sensitive context.
- Desired business outcome.
- Deadline or launch window.
- Whether you want audit, implementation, demo, licensing, or partnership.
- Budget range if already known.

Do not send passwords, app passwords, API keys, customer records, private source, signed URLs, or production credentials in the first message.

## Start A Scoped Conversation

[Contact Faith](https://faithcheltenham.com/contact/)

# Buyer FAQ

Use this page when a buyer, partner, investor, or founder is interested but needs clearer answers before requesting scope.

Primary contact path:

- `https://faithcheltenham.com/contact/`

Do not send credentials, app passwords, private source, customer data, private keys, signed URLs, production logs, or protected records in the first message.

## Is This A Product Or A Service?

It can be either, depending on the scope.

Faith currently sells quote-first advisory, implementation, cleanup, and packaging work around owner-controlled AI systems, public trust surfaces, website visual cleanup, GitHub packaging, local workflows, and provenance strategy.

Some work may also become product licensing, partnership, or productized workflow conversations after the first scope is clear.

## Why Quote-First Instead Of Fixed Public Pricing?

The work depends on surface count, risk level, access needs, publishing responsibility, review depth, urgency, and whether the buyer needs strategy, implementation, a pilot, licensing, or a partnership path.

Quote-first protects the buyer from vague open-ended work and protects Faith from underpricing high-leverage strategy or implementation.

## What Is The Fastest Paid First Step?

Pick one pilot from the Pilot Sprint Menu:

- Website Trust Sprint
- GitHub Trust Sprint
- Brand System Audit Sprint
- Local AI Workflow Sprint
- Provenance And Protected File Sprint

Then send a public URL or repo, desired outcome, deadline, and whether you want audit, implementation, demo, licensing, or partnership.

## What Should A Buyer Send First?

Send:

- your name and company or project
- public website, repo, profile, brand page, or workflow context
- what feels weak, risky, unclear, or not converting
- the outcome you want
- deadline or launch window
- whether you want audit, implementation, demo, licensing, or partnership
- budget range if known

Do not send credentials in the first message.

## What Access Is Needed?

For an initial review, public links are usually enough.

If implementation later requires WordPress, GitHub, Canva, COAI, server, or publishing access, Faith should scope a safe access path separately with clear boundaries, rollback expectations, and no unnecessary credential sharing.

## Can Faith Publish Changes Directly?

Sometimes, but only through a guarded path.

Live publishing should use approved adapters, receipts, rollback plans, and explicit scope. DNS, authentication, server config, credential changes, and sensitive account settings should not be changed casually.

For the current Faith portfolio itself, WordPress publishing remains gated until the authenticated WordPress path is available.

## What Stays Private?

Private by default:

- private engine source
- production adapters
- prompts and target registries
- credentials and app passwords
- signing keys
- rollback snapshots
- private receipts
- customer data
- protected records
- signed URLs
- production logs

Public surfaces should explain the work without giving away the private operating engine.

## Can A Buyer License The Tools?

Possibly, if the fit is right.

Licensing conversations should start with the business outcome, protected boundaries, support expectations, allowed use, excluded use, ownership terms, and whether the buyer needs product access, a managed workflow, or a custom build.

## Can A Buyer Hire Faith For Just Strategy?

Yes, if the scope is clear.

Strategy work can include public-surface review, brand trust audit, GitHub packaging plan, workflow design, provenance planning, or productization review. The deliverable should still be concrete: notes, decisions, next actions, diagrams, or a receipt-backed plan.

## Can A Buyer Hire Faith For Implementation?

Yes, when the access path and risk level are appropriate.

Implementation may include public copy, GitHub docs, website visual cleanup, static promo surfaces, review systems, local workflow structure, receipt templates, or guarded publishing support.

## What If The Buyer Has Sensitive Files?

Do not send them at first.

Start with metadata, file types, goals, and public/private boundary needs. If sensitive review becomes necessary, scope a separate handling path.

## What If The Buyer Only Wants Free Advice?

The public pages are enough for a first look. Deeper strategy, teardown, implementation planning, or product guidance should become a paid scope, pilot, or partnership conversation.

## What Makes A Strong Yes?

A strong yes has:

- a real public surface or workflow
- clear trust, conversion, proof, or workflow problem
- decision-maker or sponsor
- practical deadline
- respect for private boundaries
- willingness to scope the first step

## What Makes A No Or Not Yet?

Not a fit:

- vague unpaid advisory requests
- no decision-maker
- unclear ownership
- pressure to expose private source
- requests to bypass platform rules
- credential sharing in the first message
- public claims that are not true yet

## Where Should A Buyer Start?

Start here:

- Pilot menu: `https://thefayth.github.io/faith-ai-systems-portfolio/pilot-sprint-menu.html`
- Scope request: `https://thefayth.github.io/faith-ai-systems-portfolio/scope-request.html`
- Public proof: `https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-index.html`
- Contact: `https://faithcheltenham.com/contact/`


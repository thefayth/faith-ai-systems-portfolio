# Request Scope

Use this page when you want to ask Faith about paid work, a demo, licensing, partnership, or a product review.

Primary contact path:

- `https://faithcheltenham.com/contact/`

Do not send passwords, app passwords, API keys, signing materials, private customer records, medical/legal records, unpublished source, signed URLs, or production credentials in the first message.

## Best First Message

Include:

- Your name and company or project.
- The public website, GitHub repo, product page, or profile you want reviewed.
- The outcome you want: more trust, better visuals, a cleaner GitHub surface, a local AI workflow, a provenance strategy, or a partnership conversation.
- The deadline or launch window.
- Whether you want strategy, implementation, audit only, or a demo.
- Your rough budget range if you already know it.

## Pick A Starting Lane

### AI Website Visual Cleanup

Choose this if your website visuals look generic, repeated, broken, off-brand, AI-draft-like, or weaker than the real business.

What to send:

- public website URL
- pages or sections that bother you most
- any approved brand assets or screenshots
- whether Faith should only audit or also prepare replacement assets

### GitHub / Public Surface Packaging

Choose this if you have a private tool, product, or research system that needs a credible public GitHub surface without giving away the private engine.

What to send:

- public repo URL if one exists
- what the tool does in plain English
- what must stay private
- whether you need README/docs only or a full public-surface package

### AI Brand System Audit

Choose this if your public visuals, copy, product pages, social profiles, and docs feel fragmented or not as serious as the actual work.

What to send:

- current brand/public links
- what feels wrong
- who needs to trust the brand
- examples of what you like or strongly do not want repeated

### Local AI Workflow Setup

Choose this if you want AI help with receipts, checkpoints, review queues, file boundaries, and owner control instead of loose chat-only work.

What to send:

- what repeatable workflow you want to make easier
- whether it involves writing, design, code, review, publishing, or operations
- what tools you already use
- what should never be automated

### Protected File / Provenance Consulting

Choose this if authorship, original files, proof records, selective disclosure, and private/public boundaries matter.

What to send:

- what kinds of files need protection
- who needs to verify or review them
- what can be disclosed publicly
- what must remain private

## After You Send It

Faith will scope:

- outcome
- surface count
- access needs
- risk level
- likely deliverables
- turnaround range
- whether the work should be strategy, implementation, or a staged pilot

The first serious step is a clear scope, not an open-ended promise.


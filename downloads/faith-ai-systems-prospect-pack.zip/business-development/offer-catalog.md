# Quote-First Offer Catalog

All offers are scoped by request. Do not publish fixed prices yet. The public CTA is: "Request a scoped project" through `https://faithcheltenham.com/contact/`.

## AI Website Visual Cleanup

Best for: founders, creators, small businesses, and organizations whose website visuals look generic, broken, repeated, off-brand, AI-draft-like, or inconsistent.

Outcome: a sharper public website image system with clearer trust, better brand fit, and safer publishing receipts.

Deliverables:

- Public visual audit with keep/change/remove recommendations.
- Replacement plan by route, section, asset type, and risk.
- Final asset candidates or import-ready asset list.
- Source and usage receipts where available.
- Publish-ready handoff or guarded WordPress/COAI implementation where supported.

Turnaround range: focused sprint to multi-site cleanup, depending on page count and publishing access.

CTA: Request a scoped visual cleanup at `https://faithcheltenham.com/contact/`.

## GitHub / Public Surface Packaging

Best for: builders with private tools who need a public GitHub surface for credibility, customers, investors, or collaborators without leaking private source.

Outcome: a public-safe repository that explains the product, protects IP, and points visitors toward a commercial next step.

Deliverables:

- Public/private boundary review.
- README, license posture, notice, security, roadmap, FAQ, and status docs.
- Public-safe diagrams and screenshots.
- Secret/private-path scan guidance.
- Launch receipt and CTA alignment.

Turnaround range: single product surface to multi-repo portfolio package.

CTA: Request GitHub packaging at `https://faithcheltenham.com/contact/`.

## AI Brand System Audit

Best for: founders and teams whose public visuals, copy, and product surfaces feel fragmented or do not reflect the actual strategic identity of the brand.

Outcome: a brand intelligence map that tells the team what to keep, what to change, and what should never be repeated.

Deliverables:

- Brand fit audit across website, GitHub, docs, and social/profile surfaces.
- Visual language and voice notes.
- Rejected pattern list.
- Accessibility, trust, and conversion review.
- Next-batch creative brief.

Turnaround range: one brand surface to full ecosystem review.

CTA: Request a brand audit at `https://faithcheltenham.com/contact/`.

## Local AI Workflow Setup

Best for: operators who want AI help without giving up local control, files, receipts, or approval boundaries.

Outcome: a local-first operating lane for repeatable AI work with checkpoints, receipts, and safer handoffs.

Deliverables:

- Workflow map.
- Local folder and receipt structure.
- Task packet templates.
- Safe automation rules.
- Training walkthrough for the owner/operator.

Turnaround range: starter workflow to full local desktop command-center setup.

CTA: Request a local AI workflow setup at `https://faithcheltenham.com/contact/`.

## Protected File / Provenance Consulting

Best for: creators, technologists, researchers, and founders who need better ways to preserve original files, metadata, proof records, and selective disclosure boundaries.

Outcome: a practical provenance strategy that protects original bytes, authorship, and future review.

Deliverables:

- Provenance needs assessment.
- File proof and disclosure workflow.
- Public/private data boundary.
- Local receipt structure.
- TheFAYTH File Type concept walkthrough where appropriate.

Turnaround range: advisory session to custom workflow buildout.

CTA: Request provenance consulting at `https://faithcheltenham.com/contact/`.


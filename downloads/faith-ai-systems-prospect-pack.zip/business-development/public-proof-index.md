# Public Proof Index

Use this page for quick diligence before a scoped project, partnership conversation, pilot, or investor/customer review.

This is a public-safe proof index. It shows live surfaces and commercial boundaries without exposing private engine source, credentials, customer data, prompts, adapters, rollback snapshots, signing keys, private receipts, or production workflows.

## Fast Verification Links

Check these first:

- Portfolio and offers: `https://thefayth.github.io/faith-ai-systems-portfolio/`
- Buyer trust matrix: `https://thefayth.github.io/faith-ai-systems-portfolio/buyer-trust-matrix.html`
- Request scope: `https://thefayth.github.io/faith-ai-systems-portfolio/scope-request.html`
- Referral kit: `https://thefayth.github.io/faith-ai-systems-portfolio/referral-introduction-kit.html`
- Investor and partner brief: `https://thefayth.github.io/faith-ai-systems-portfolio/investor-partner-brief.html`
- Public proof snapshots: `https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-snapshots.html`
- Proof and boundaries: `https://thefayth.github.io/faith-ai-systems-portfolio/proof-and-boundaries.html`
- FaithCheltenham contact: `https://faithcheltenham.com/contact/`

## Public Product Surfaces

The public repos are intentionally promotional, documentation, trust, and packaging surfaces. They do not grant access to private systems.

| Surface | Public URL | What it is for |
| --- | --- | --- |
| TheFAYTH Visual Empire | `https://github.com/thefayth/thefayth-visual-empire` | Public-safe surface for the website visual engine and creative autopilot concept. |
| TheFAYTH File Type | `https://github.com/thefayth/thefayth-file-type` | Public-safe surface for protected file, provenance, and disclosure concepts. |
| Fantasia | `https://github.com/thefayth/fantas1a` | Public-safe surface for local AI operations and task-conductor positioning. |

## Public Service Lanes

Faith can scope:

- AI Website Visual Cleanup
- GitHub / Public Surface Packaging
- AI Brand System Audit
- Local AI Workflow Setup
- Protected File / Provenance Consulting

Each lane is quote-first. The first serious step is scope: surface count, risk level, access needs, deliverables, turnaround range, and whether the work is advisory, implementation, or a pilot.

## Current Live Status

As of this pack, the GitHub Pages portfolio is live and verified. It includes:

- portfolio overview
- quote-first offers
- buyer trust matrix
- individual offer pages
- request scope guide
- referral introduction kit
- investor and partner brief
- proof and boundaries
- product one-pagers
- intake guide
- sitemap and robots file

FaithCheltenham.com currently has live public paths for:

- TheFAYTH Visual Empire project page
- TheFAYTH File Type project page
- contact page

The canonical WordPress pages still pending are:

- `/work-with-faith/`
- `/projects/fantasia/`

Until those WordPress pages are live, the GitHub Pages portfolio is the verified public fallback.

## What The Public Surfaces Prove

- Faith has a coherent public AI systems portfolio.
- Buyers can review offers, scope criteria, and contact paths without receiving private files.
- Buyers can map their concern to the safest public proof and first paid path.
- The three major product surfaces are connected to public commercial CTAs.
- The system distinguishes public proof from private engine access.
- The current launch state has receipts and repeatable verification scripts.

## What The Public Surfaces Do Not Claim

The public pages do not claim:

- open-source release of private engines
- legal notarization
- guaranteed security
- public access to production adapters
- permission to train on private materials
- right to redistribute private assets
- automatic access to live WordPress, COAI, Canva, GitHub, or server credentials

## What Serious Buyers Should Send

Use the contact page and include:

- who you are
- the public website, repo, brand, profile, or workflow you want reviewed
- the outcome you want
- launch window or deadline
- whether you want audit, implementation, demo, licensing, or partnership
- budget range if already known

Do not send credentials in the first message.

## Best Fit

The best-fit buyer or partner has a real public surface, a trust or presentation gap, and authority to sponsor a scoped improvement.

The strongest fit is not someone asking for vague unpaid strategy. It is someone ready to turn a public-surface problem into a bounded paid scope, pilot, licensing conversation, or partnership review.

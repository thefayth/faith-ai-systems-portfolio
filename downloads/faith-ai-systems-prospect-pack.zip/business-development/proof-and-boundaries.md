# Proof And Boundaries

Faith Cheltenham's public AI systems portfolio is built to show enough to earn trust without exposing the private engine.

## What Is Live

- Live portfolio and offers: `https://thefayth.github.io/faith-ai-systems-portfolio/`
- TheFAYTH Visual Empire GitHub surface: `https://github.com/thefayth/thefayth-visual-empire`
- TheFAYTH File Type GitHub surface: `https://github.com/thefayth/thefayth-file-type`
- Fantasia GitHub surface: `https://github.com/thefayth/fantas1a`
- FaithCheltenham.com contact path: `https://faithcheltenham.com/contact/`

## What The Public Surfaces Prove

- The portfolio has a working public fallback while WordPress publishing is gated.
- Each public repo has a contact CTA, Work With Faith page, and commercial offers page.
- Each public product surface names its private boundary.
- Dedicated offer pages are live for the main paid service lanes.
- Public pages route prospects to a scoped project request instead of exposing private workflows.

## What Remains Protected

- Private source code.
- Production adapters.
- Prompts and target registries.
- Credentials and app passwords.
- Rollback snapshots.
- Private receipts.
- Customer data.
- Signed URLs.
- Server details.
- Private operational workflows.

## Publishing Status

FaithCheltenham.com already has live pages for:

- TheFAYTH Visual Empire.
- TheFAYTH File Type.
- Contact.

The canonical WordPress pages still pending are:

- `/work-with-faith/`
- `/projects/fantasia/`

Until those pages are live, the GitHub Pages portfolio is the public fallback.

## Commercial Boundary

The public portfolio explains the work and supports paid scoping conversations. It does not grant source release, redistribution permission, training permission, commercial-use permission, or access to private systems.

## Request Scope

Request a scoped project, demo, licensing conversation, or partnership review: `https://faithcheltenham.com/contact/`


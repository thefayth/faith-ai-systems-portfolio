# Pilot Sprint Menu

Use this page when a buyer, partner, investor, or founder asks what the first paid step should be.

The menu is quote-first. It does not publish fixed public pricing. Each pilot is scoped around surfaces, risk, access needs, turnaround, and whether the work is advisory, implementation, or a productization conversation.

Primary contact path:

- `https://faithcheltenham.com/contact/`

Do not send credentials, private source, customer data, app passwords, signed URLs, private keys, or production logs in the first message.

## Pick One First Step

### Website Trust Sprint

Best for a business, founder, creator, or organization whose public site looks weaker than the actual work.

Use it when the site has:

- generic or repeated visuals
- outdated project pages
- unclear calls to action
- weak proof and trust signals
- images that feel draft-like, broken, empty, or off-brand
- good work hidden behind poor presentation

Pilot deliverables:

- public route and image audit
- keep/change/remove list
- first-batch replacement plan
- source and usage boundary notes
- CTA and trust-signal cleanup recommendations
- publish-ready handoff or guarded implementation path where supported

Good first message:

Send the website URL, the pages that bother you most, launch deadline, and whether you want audit only or implementation support.

### GitHub Trust Sprint

Best for a private or semi-private technical product that needs public credibility without giving away the private engine.

Use it when the repo or public surface needs:

- clearer README
- public/private boundary language
- better product positioning
- license and commercial-use clarity
- safer screenshots or diagrams
- contact and commercial CTAs
- proof that the project exists without exposing sensitive implementation

Pilot deliverables:

- public/private boundary review
- README and commercial CTA upgrade
- docs structure recommendation
- secret and private-file risk notes
- public-safe proof links
- launch receipt

Good first message:

Send the public repo URL if one exists, what the tool does, what must stay private, and what kind of buyer or partner should understand it.

### Brand System Audit Sprint

Best for a founder or team whose public materials feel inconsistent across website, GitHub, social/profile pages, docs, and pitch surfaces.

Use it when the brand has:

- mixed visual language
- unclear tone
- weak audience fit
- inconsistent calls to action
- trust problems across surfaces
- AI visuals that do not match the real brand

Pilot deliverables:

- brand-fit map
- voice and visual notes
- rejected pattern list
- accessibility and trust review
- next creative batch brief
- buyer-facing positioning notes

Good first message:

Send the public links, who needs to trust the brand, what feels wrong, and examples of visual/copy directions you like or do not want repeated.

### Local AI Workflow Sprint

Best for operators who want AI help without losing control of files, receipts, reviews, and publishing authority.

Use it when the workflow needs:

- repeatable task packets
- local-first file organization
- approval checkpoints
- receipts and logs
- public/private separation
- safer handoff from idea to asset to publish

Pilot deliverables:

- workflow map
- folder and receipt structure
- task packet template
- safe automation rules
- owner review checklist
- training walkthrough

Good first message:

Send the repeatable workflow you want to improve, the tools you already use, and what should never be automated.

### Provenance And Protected File Sprint

Best for creators, founders, researchers, and technologists who need better authorship, original-file, disclosure, and review records.

Use it when the work involves:

- original files that must remain unchanged
- selective disclosure
- private/public proof boundaries
- authorship and ownership records
- archive or diligence readiness
- tamper-evident local receipts

Pilot deliverables:

- provenance needs map
- public/private disclosure boundary
- local receipt structure
- original-file handling notes
- proof-language review
- TheFAYTH File Type concept walkthrough where appropriate

Good first message:

Send the kinds of files involved, who needs to review them, what can be disclosed publicly, and what must remain private.

## What Happens After A Pilot

A pilot can lead to:

- a larger implementation project
- a monthly public-surface improvement lane
- a product packaging sprint
- licensing or partnership conversation
- investor/customer diligence support
- a local workflow buildout

## Buyer Fit

Best fit:

- you have a real public surface
- there is a trust, clarity, workflow, or proof problem
- you can name the outcome you want
- you respect public/private boundaries
- you are ready to scope the first step

Poor fit:

- vague unpaid strategy requests
- credential sharing in the first message
- requests to expose private engine source
- unclear ownership
- no decision-maker or sponsor
- public claims that are not true yet

## Ask For A Scope

Use the contact page and say which pilot you want to discuss.

Include:

- your public URL or repo
- desired outcome
- deadline or launch window
- whether you want audit, implementation, demo, licensing, or partnership
- budget range if known


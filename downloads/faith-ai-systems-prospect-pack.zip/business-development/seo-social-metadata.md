# SEO And Social Metadata

Use this metadata when publishing the missing FaithCheltenham.com pages or updating public project pages.

## Work With Faith

Path: `/work-with-faith/`

Title: `Work With Faith | AI Systems, Visual Cleanup, Provenance, and Public Surfaces`

Description: `Hire Faith Cheltenham for quote-first AI website visual cleanup, GitHub public surface packaging, AI brand audits, local AI workflow setup, and protected-file provenance consulting.`

Primary CTA: `Request a scoped project`

Canonical URL: `https://faithcheltenham.com/work-with-faith/`

Suggested OG image: use an approved FaithCheltenham or FVE ecosystem visual that does not reveal private UI, credentials, or internal workflows.

## Fantasia

Path: `/projects/fantasia/`

Title: `Fantasia | Local-First AI Operations Desktop`

Description: `Fantasia is Faith Cheltenham's local-first AI operations desktop for safe creative automation, receipts, review queues, task packets, and guarded publishing readiness.`

Primary CTA: `Request a scoped project`

Canonical URL: `https://faithcheltenham.com/projects/fantasia/`

GitHub URL: `https://github.com/thefayth/fantas1a`

Suggested OG image: use the approved Fantasia public social card or a real product screenshot that does not expose private data.

## TheFAYTH Visual Empire

Path: `/projects/thefayth-visual-empire/`

Title: `TheFAYTH Visual Empire | Website Visual Engine And Guarded Publishing`

Description: `TheFAYTH Visual Empire is Faith Cheltenham's local-first website visual engine for image review, brand memory, source receipts, slot mapping, and guarded COAI publishing.`

Primary CTA: `Request a scoped visual cleanup`

Canonical URL: `https://faithcheltenham.com/projects/thefayth-visual-empire/`

GitHub URL: `https://github.com/thefayth/thefayth-visual-empire`

## TheFAYTH File Type

Path: `/projects/thefayth-file-type/`

Title: `TheFAYTH File Type | Protected File Provenance And Selective Disclosure`

Description: `TheFAYTH File Type is Faith Cheltenham's protected file and provenance concept for original bytes, local receipts, tamper-evident checks, and selective disclosure.`

Primary CTA: `Request provenance consulting`

Canonical URL: `https://faithcheltenham.com/projects/thefayth-file-type/`

GitHub URL: `https://github.com/thefayth/thefayth-file-type`


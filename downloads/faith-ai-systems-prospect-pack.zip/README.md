# Faith Cheltenham AI Systems Prospect Packet

Public-safe materials for buyers, investors, partners, and referral sources.

## How To Use

- Review before sending.
- Send as a public-safe packet when someone asks what Faith builds, sells, or can scope.
- Point serious prospects to `https://faithcheltenham.com/contact/`.
- Do not add pricing sheets, private proposal drafts, client records, credentials, payment links, or production receipts.

## Included Files

- `business-development/buyer-faq.md`
- `business-development/investor-partner-brief.md`
- `business-development/offer-catalog.md`
- `business-development/one-pagers/faith-cheltenham-ai-systems-portfolio.md`
- `business-development/one-pagers/fantasia.md`
- `business-development/one-pagers/thefayth-file-type.md`
- `business-development/one-pagers/thefayth-visual-empire.md`
- `business-development/pilot-sprint-menu.md`
- `business-development/proof-and-boundaries.md`
- `business-development/public-proof-index.md`
- `business-development/referral-introduction-kit.md`
- `business-development/sample-deliverables.md`
- `business-development/scope-request.md`
- `business-development/seo-social-metadata.md`
- `business-development/share-send-kit.md`
- `business-development/shareable/fantasia.html`
- `business-development/shareable/fve.html`
- `business-development/shareable/index.html`
- `business-development/shareable/intake-questionnaire.html`
- `business-development/shareable/manifest.json`
- `business-development/shareable/offer-catalog.html`
- `business-development/shareable/portfolio.html`
- `business-development/shareable/thefayth-file-type.html`
- `business-development/static-site/.nojekyll`
- `business-development/static-site/README.md`
- `business-development/static-site/ai-brand-system-audit.html`
- `business-development/static-site/ai-website-visual-cleanup.html`
- `business-development/static-site/assets/site.css`
- `business-development/static-site/buyer-faq.html`
- `business-development/static-site/fantasia.html`
- `business-development/static-site/fve.html`
- `business-development/static-site/github-public-surface-packaging.html`
- `business-development/static-site/index.html`
- `business-development/static-site/intake.html`
- `business-development/static-site/investor-partner-brief.html`
- `business-development/static-site/local-ai-workflow-setup.html`
- `business-development/static-site/offers.html`
- `business-development/static-site/pilot-sprint-menu.html`
- `business-development/static-site/proof-and-boundaries.html`
- `business-development/static-site/prospect-packet.html`
- `business-development/static-site/protected-file-provenance-consulting.html`
- `business-development/static-site/public-proof-index.html`
- `business-development/static-site/referral-introduction-kit.html`
- `business-development/static-site/robots.txt`
- `business-development/static-site/sample-deliverables.html`
- `business-development/static-site/scope-request.html`
- `business-development/static-site/share-send-kit.html`
- `business-development/static-site/sitemap.xml`
- `business-development/static-site/thefayth-file-type.html`
- `business-development/static-site/work-with-faith.html`

## Explicitly Excluded

- `business-development/pricing`
- `business-development/proposals/generated`
- `business-development/onboarding/generated`
- `business-development/lead-tracker.csv`
- `business-development/lead-pipeline.json`
- `business-development/outreach/today-outreach-packet.json`
- `business-development/verification`
- `business-development/wordpress-ready`
- `business-development/ops-status.json`

## Core Public Links

# Public Links

- Portfolio: https://thefayth.github.io/faith-ai-systems-portfolio/
- Work with Faith: https://thefayth.github.io/faith-ai-systems-portfolio/work-with-faith.html
- Prospect packet page: https://thefayth.github.io/faith-ai-systems-portfolio/prospect-packet.html
- Prospect packet download: https://thefayth.github.io/faith-ai-systems-portfolio/downloads/faith-ai-systems-prospect-pack.zip
- Share / send kit: https://thefayth.github.io/faith-ai-systems-portfolio/share-send-kit.html
- Pilot sprint menu: https://thefayth.github.io/faith-ai-systems-portfolio/pilot-sprint-menu.html
- Sample deliverables: https://thefayth.github.io/faith-ai-systems-portfolio/sample-deliverables.html
- Buyer FAQ: https://thefayth.github.io/faith-ai-systems-portfolio/buyer-faq.html
- Public proof index: https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-index.html
- Public proof snapshots: https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-snapshots.html
- Referral kit: https://thefayth.github.io/faith-ai-systems-portfolio/referral-introduction-kit.html
- Contact: https://faithcheltenham.com/contact/
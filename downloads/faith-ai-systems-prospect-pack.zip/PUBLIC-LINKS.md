# Public Links

- Portfolio: https://thefayth.github.io/faith-ai-systems-portfolio/
- Work with Faith: https://thefayth.github.io/faith-ai-systems-portfolio/work-with-faith.html
- Prospect packet page: https://thefayth.github.io/faith-ai-systems-portfolio/prospect-packet.html
- Prospect packet download: https://thefayth.github.io/faith-ai-systems-portfolio/downloads/faith-ai-systems-prospect-pack.zip
- Share / send kit: https://thefayth.github.io/faith-ai-systems-portfolio/share-send-kit.html
- Pilot sprint menu: https://thefayth.github.io/faith-ai-systems-portfolio/pilot-sprint-menu.html
- Sample deliverables: https://thefayth.github.io/faith-ai-systems-portfolio/sample-deliverables.html
- Buyer FAQ: https://thefayth.github.io/faith-ai-systems-portfolio/buyer-faq.html
- Public proof index: https://thefayth.github.io/faith-ai-systems-portfolio/public-proof-index.html
- Referral kit: https://thefayth.github.io/faith-ai-systems-portfolio/referral-introduction-kit.html
- Contact: https://faithcheltenham.com/contact/